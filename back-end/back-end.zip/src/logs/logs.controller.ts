import { Controller, Get, Post, Body, Param, Delete, ParseIntPipe, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { LogsService } from './logs.service';
import { CreateLogDto } from './dto/create-log.dto';
import { Log } from '../entities/log.entity';

@ApiTags('logs')
@ApiBearerAuth('JWT-auth')
@Controller('logs')
export class LogsController {
  constructor(private readonly logsService: LogsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new log entry' })
  @ApiResponse({ status: 201, description: 'Log created successfully', type: Log })
  create(@Body() createLogDto: CreateLogDto) {
    return this.logsService.create(createLogDto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all logs' })
  @ApiQuery({ name: 'level', required: false, type: String, description: 'Filter by log level' })
  @ApiQuery({ name: 'userId', required: false, type: String, description: 'Filter by user ID/username' })
  @ApiQuery({ name: 'username', required: false, type: String, description: 'Filter by username' })
  @ApiQuery({ name: 'limit', required: false, type: Number, description: 'Limit number of results' })
  @ApiResponse({ status: 200, description: 'List of all logs', type: [Log] })
  findAll(
    @Query('level') level?: string,
    @Query('userId') userId?: string,
    @Query('username') username?: string,
    @Query('limit') limit?: number,
  ) {
    if (level) {
      return this.logsService.findByLevel(level);
    }
    if (userId) {
      return this.logsService.findByUserId(userId);
    }
    if (username) {
      return this.logsService.findByUsername(username);
    }
    return this.logsService.findAll(limit ? Number(limit) : undefined);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a log by ID' })
  @ApiResponse({ status: 200, description: 'Log found', type: Log })
  @ApiResponse({ status: 404, description: 'Log not found' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.logsService.findOne(id);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a log' })
  @ApiResponse({ status: 200, description: 'Log deleted successfully' })
  @ApiResponse({ status: 404, description: 'Log not found' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.logsService.remove(id);
  }

  @Delete()
  @ApiOperation({ summary: 'Delete all logs' })
  @ApiResponse({ status: 200, description: 'All logs deleted successfully' })
  removeAll() {
    return this.logsService.removeAll();
  }
}

