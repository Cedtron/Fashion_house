import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Log } from '../entities/log.entity';
import { CreateLogDto } from './dto/create-log.dto';

@Injectable()
export class LogsService {
  constructor(
    @InjectRepository(Log)
    private logsRepository: Repository<Log>,
  ) {}

  async create(createLogDto: CreateLogDto): Promise<Log> {
    const log = this.logsRepository.create(createLogDto);
    return this.logsRepository.save(log);
  }

  async findAll(limit?: number): Promise<Log[]> {
    return this.logsRepository.find({
      order: { createdAt: 'DESC' },
      take: limit,
    });
  }

  async findOne(id: number): Promise<Log> {
    const log = await this.logsRepository.findOne({ where: { id } });
    if (!log) {
      throw new NotFoundException(`Log with ID ${id} not found`);
    }
    return log;
  }

  async findByLevel(level: string): Promise<Log[]> {
    return this.logsRepository.find({
      where: { level },
      order: { createdAt: 'DESC' },
    });
  }

  async findByUserId(userId: string): Promise<Log[]> {
    return this.logsRepository.find({
      where: { userId },
      order: { createdAt: 'DESC' },
    });
  }

  async findByUsername(username: string): Promise<Log[]> {
    return this.logsRepository.find({
      where: { username },
      order: { createdAt: 'DESC' },
    });
  }

  async remove(id: number): Promise<void> {
    const log = await this.findOne(id);
    await this.logsRepository.remove(log);
  }

  async removeAll(): Promise<void> {
    await this.logsRepository.clear();
  }
}

